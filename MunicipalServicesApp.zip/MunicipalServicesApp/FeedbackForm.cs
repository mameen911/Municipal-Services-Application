﻿using System;
using System.Windows.Forms;

namespace MunicipalServicesApp
{
    public partial class FeedbackForm : Form
    {
        private Issue _issue;

        public FeedbackForm(Issue issue)
        {
            InitializeComponent();
            _issue = issue;
        }

        private void btnSubmitFeedback_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(rtbFeedback.Text) || cmbRating.SelectedIndex == -1)
            {
                MessageBox.Show("Please provide feedback and a rating.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Update the issue with feedback and rating
            _issue.Feedback = rtbFeedback.Text;
            _issue.Rating = int.Parse(cmbRating.SelectedItem.ToString());

            MessageBox.Show("Thank you for your feedback!", "Feedback Submitted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
    }
}
