﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MunicipalServicesApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReportIssues_Click(object sender, EventArgs e)
        {
            ReportIssuesForm reportIssuesForm = new ReportIssuesForm();
            reportIssuesForm.Show();
            this.Hide();
        }

        private void btnLocalEventsAndAnnouncements_Click(object sender, EventArgs e)
        {
            // Placeholder for future implementation
        }

        private void btnServiceRequestStatus_Click(object sender, EventArgs e)
        {
            // Placeholder for future implementation
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
