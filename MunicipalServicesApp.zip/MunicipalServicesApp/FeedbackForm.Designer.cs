﻿namespace MunicipalServicesApp
{
    partial class FeedbackForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblFeedback;
        private System.Windows.Forms.Label lblRating;
        private System.Windows.Forms.RichTextBox rtbFeedback;
        private System.Windows.Forms.ComboBox cmbRating;
        private System.Windows.Forms.Button btnSubmitFeedback;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblFeedback = new System.Windows.Forms.Label();
            this.lblRating = new System.Windows.Forms.Label();
            this.rtbFeedback = new System.Windows.Forms.RichTextBox();
            this.cmbRating = new System.Windows.Forms.ComboBox();
            this.btnSubmitFeedback = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblFeedback
            // 
            this.lblFeedback.AutoSize = true;
            this.lblFeedback.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblFeedback.Location = new System.Drawing.Point(12, 9);
            this.lblFeedback.Name = "lblFeedback";
            this.lblFeedback.Size = new System.Drawing.Size(85, 23);
            this.lblFeedback.TabIndex = 0;
            this.lblFeedback.Text = "Feedback:";
            // 
            // lblRating
            // 
            this.lblRating.AutoSize = true;
            this.lblRating.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblRating.Location = new System.Drawing.Point(12, 145);
            this.lblRating.Name = "lblRating";
            this.lblRating.Size = new System.Drawing.Size(63, 23);
            this.lblRating.TabIndex = 1;
            this.lblRating.Text = "Rating:";
            // 
            // rtbFeedback
            // 
            this.rtbFeedback.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.rtbFeedback.Location = new System.Drawing.Point(12, 35);
            this.rtbFeedback.Name = "rtbFeedback";
            this.rtbFeedback.Size = new System.Drawing.Size(360, 100);
            this.rtbFeedback.TabIndex = 2;
            this.rtbFeedback.Text = "";
            // 
            // cmbRating
            // 
            this.cmbRating.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRating.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbRating.FormattingEnabled = true;
            this.cmbRating.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cmbRating.Location = new System.Drawing.Point(12, 171);
            this.cmbRating.Name = "cmbRating";
            this.cmbRating.Size = new System.Drawing.Size(360, 31);
            this.cmbRating.TabIndex = 3;
            // 
            // btnSubmitFeedback
            // 
            this.btnSubmitFeedback.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(123)))), ((int)(((byte)(255)))));
            this.btnSubmitFeedback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmitFeedback.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnSubmitFeedback.ForeColor = System.Drawing.Color.White;
            this.btnSubmitFeedback.Location = new System.Drawing.Point(138, 220);
            this.btnSubmitFeedback.Name = "btnSubmitFeedback";
            this.btnSubmitFeedback.Size = new System.Drawing.Size(100, 35);
            this.btnSubmitFeedback.TabIndex = 4;
            this.btnSubmitFeedback.Text = "Submit";
            this.btnSubmitFeedback.UseVisualStyleBackColor = false;
            this.btnSubmitFeedback.Click += new System.EventHandler(this.btnSubmitFeedback_Click);
            // 
            // FeedbackForm
            // 
            this.BackgroundImage = global::MunicipalServicesApp.Properties.Resources.images;
            this.ClientSize = new System.Drawing.Size(384, 281);
            this.Controls.Add(this.btnSubmitFeedback);
            this.Controls.Add(this.cmbRating);
            this.Controls.Add(this.rtbFeedback);
            this.Controls.Add(this.lblRating);
            this.Controls.Add(this.lblFeedback);
            this.Name = "FeedbackForm";
            this.Text = "Submit Feedback";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
